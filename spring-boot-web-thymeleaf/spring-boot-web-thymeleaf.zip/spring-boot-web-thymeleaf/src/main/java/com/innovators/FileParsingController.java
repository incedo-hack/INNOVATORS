package com.innovators;

import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Controller;

@Controller
@Configuration
@PropertySource("classpath:skills.properties")
public class FileParsingController {
	
	

}
