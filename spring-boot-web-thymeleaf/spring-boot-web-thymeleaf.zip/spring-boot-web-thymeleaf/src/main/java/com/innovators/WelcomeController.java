package com.innovators;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Properties;

import org.apache.tika.Tika;
import org.apache.tika.exception.TikaException;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import edu.stanford.nlp.ling.CoreAnnotations;
import edu.stanford.nlp.ling.CoreLabel;
import edu.stanford.nlp.pipeline.Annotation;
import edu.stanford.nlp.pipeline.StanfordCoreNLP;
import edu.stanford.nlp.util.CoreMap;


@Controller
@Configuration
@PropertySource("classpath:skills.properties")
public class WelcomeController {

	// inject via application.properties
	@Value("${welcome.message:test}")
	private String message;
	
	@Value("${skills.list}")
	private String skillList;
	
	@RequestMapping("/")
	public String welcome(Model model) {		
		model.addAttribute("message", this.message);
		return "welcome";
	}
	
	@PostMapping("/upload") 
    public ModelAndView singleFileUpload(@RequestParam("file") MultipartFile file,
                                   RedirectAttributes redirectAttributes) {
       ModelAndView modelandview = new ModelAndView("TextData");
        try {
        	Tika tika = new Tika();        	
        	File f = convert(file);            
        	String filecontent = tika.parseToString(f);            
            modelandview.addObject("fileContent",filecontent);
            
            if (filecontent.length()>200)  getName(filecontent.substring(1, 200));
            
            getEmail(filecontent);
            getExperience(filecontent);
            getCellNumber(Arrays.copyOfRange(filecontent.replace('\n', ' ').replace('\t',' ').replaceAll(" +", " ").split(" "),0,20));
         
        } catch (IOException e) {
            e.printStackTrace();
        } catch (TikaException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
        
        return modelandview;
    }
	
	private void getEmail(String filecontent) {		
		
		char[] separatorArray = {' ','\t','\n','\r',':','|'};
		int startIndex = 0 ; 
		String firstStr = filecontent.substring(0,filecontent.indexOf("@"));
		
		int endIndex = 
				(filecontent.indexOf("@")+filecontent.substring(filecontent.indexOf("@")).indexOf(" ") > filecontent.indexOf("@")+filecontent.substring(filecontent.indexOf("@")).indexOf("\n"))?filecontent.indexOf("@")+filecontent.substring(filecontent.indexOf("@")).indexOf("\n"):filecontent.indexOf("@")+filecontent.substring(filecontent.indexOf("@")).indexOf(" ");		
		for (char ch : separatorArray) {
				startIndex = Math.max(firstStr.lastIndexOf(ch), startIndex) ;
		}
		String email = filecontent.substring(startIndex+1,endIndex );
		System.out.println("Email id is "+email);
	}

	private File convert(MultipartFile file) throws IOException
	{    
	    File convFile = new File(file.getOriginalFilename());
	    convFile.createNewFile(); 
	    FileOutputStream fos = new FileOutputStream(convFile); 
	    fos.write(file.getBytes());
	    fos.close(); 
	    return convFile;
	}
	
	private void getName(String text) {
		// creates a StanfordCoreNLP object, with POS tagging, lemmatization, NER, parsing, and coreference resolution
        Properties props = new Properties();
        props.setProperty("annotators", "tokenize, ssplit, pos, lemma, ner, parse, dcoref");
        StanfordCoreNLP pipeline = new StanfordCoreNLP(props);
        // read some text in the text variable        
        // create an empty Annotation just with the given text
        Annotation document = new Annotation(text);

        // run all Annotators on this text
        pipeline.annotate(document);
        List<CoreMap> sentences = document.get(CoreAnnotations.SentencesAnnotation.class);

        for (CoreMap sentence : sentences) {
            // traversing the words in the current sentence
            // a CoreLabel is a CoreMap with additional token-specific methods
            for (CoreLabel token : sentence.get(CoreAnnotations.TokensAnnotation.class)) {
                // this is the text of the token
                String word = token.get(CoreAnnotations.TextAnnotation.class);
                // this is the POS tag of the token
                String pos = token.get(CoreAnnotations.PartOfSpeechAnnotation.class);
                // this is the NER label of the token
                String ne = token.get(CoreAnnotations.NamedEntityTagAnnotation.class);
                
                //System.out.println(String.format("Print: word: [%s] pos: [%s] ne: [%s]", word, pos, ne));
                if (pos.equalsIgnoreCase("NNP") && ne.equalsIgnoreCase("PERSON")) {
                	System.out.println(word);
                }else continue;
            }
        }
	}
	
	private void getExperience(String filecontent) {
		int lastIndex = filecontent.substring(0, filecontent.indexOf("ears")).lastIndexOf(" ");
		int firstIndex = filecontent.substring(0, lastIndex).lastIndexOf(" ");
		System.out.print(filecontent.substring(firstIndex+1,lastIndex));
		//System.out.print(filecontent.substring(filecontent.indexOf("ears")-10, filecontent.indexOf("ears")).replaceAll("[^0-9]", ""));
		System.out.println(" years of experience");
	}
	
	private void getCellNumber(String[] words) {
		StringBuffer cellNo =new StringBuffer();
		for (String word : words) {
			if (word.indexOf('@')==-1) {
				if (checkForNumber(word)) {
					cellNo.append(word);
				}
			}
		}
		System.out.println("Cell Number is "+cellNo);
		
	}
	
	private boolean checkForNumber(String word){
		for (int i = 0; i < word.length(); i++)
		{
			char c = word.charAt(i);
			if (Character.isDigit(c))
			{
				return true;
			}
		}
		return false;
	}
	
	private void saveSkills(String filecontent) {
		String[] skills = skillList.split(",");
		String[] text = filecontent.replaceAll("\n", " ").replaceAll("\t", " ").replaceAll(" +", " ").split(" ");
		
		List<String> skillList = new ArrayList<String>(); 
		skillList =	Arrays.asList(skills);
		
		try {
			File file = new File("test.properties");
			FileInputStream fileInput = new FileInputStream(file);
			Properties properties = new Properties();
			properties.load(fileInput);
			fileInput.close();
			
			for (String word : text) {
				if (skillList.contains(word.trim().toLowerCase())) {
					System.out.println(properties.getProperty(word));
				}
			}
			
			//Continue from here
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}